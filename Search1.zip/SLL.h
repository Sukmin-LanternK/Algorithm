//#pragma once
//#include <stdio.h>
//#include <stdlib.h>
//
//typedef int ElementType;
//
//typedef struct tagNode {
//	ElementType Data;
//	struct tagNode* NextNode;
//}Node;
//
//Node* SLL_CreatNode(ElementType NewData);
//void SLL_DestroyNode(Node* Node);
//
//void SLL_AppendNode(Node** Head, Node* NewNode);
//void SLL_RemoveNode(Node** Head, Node* Remove);
//void SLL_InsertNode(Node* Current, Node* Insert);
//
//Node* SLL_GetNodeAt(Node* Head, int Location);
//int SLL_GetNodeCount(Node* Head);
//
//Node* SLL_SequentialSearch(Node* Head, int Target);