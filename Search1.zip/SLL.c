//#include "SLL.h"
//
//Node* SLL_CreatNode(ElementType NewData) {
//	// ������ �ƴ� ���� ����ϹǷ�, ������ ��� ����Ű������ �̿��Ͽ� Node ��ȸ 
//	Node* NewNode = (Node*)malloc(sizeof(Node));
//	NewNode->Data = NewData;
//	NewNode->NextNode = NULL;
//	return NewNode;
//}
//
//void SLL_DestroyNode(Node* Node) {
//	free(Node);
//}
//
//void SLL_AppendNode(Node** Head, Node* NewNode) {
//	if (*Head == NULL)*Head = NewNode;
//	else {
//		Node* Tail = (*Head);
//		while (Tail->NextNode != NULL) {
//			Tail = Tail->NextNode;
//		}
//		Tail->NextNode = NewNode;
//	}
//}
//
//Node* SLL_GetNodeAt(Node* Head, int Location) {
//
//	Node* Current = Head;
//	while (Current != NULL && --Location >= 0) {
//		Current = Current->NextNode;
//	}
//	return Current;
//}
//
//void SLL_RemoveNode(Node** Head, Node* Remove) {
//	if (*Head == Remove) *Head = Remove->NextNode;
//	else {
//		Node* Current = *Head;
//		while (Current != NULL && Current->NextNode != Remove) {
//			Current = Current->NextNode;
//		}
//		if (Current != NULL) Current->NextNode = Remove->NextNode;
//	}
//
//	SLL_DestroyNode(Remove);
//}
//
//void SLL_InsertNode(Node* Current, Node* Insert) {
//	Insert->NextNode = Current->NextNode;
//	Current->NextNode = Insert;
//
//}
//
//int SLL_GetNodeCount(Node* Head) {
//	int count = 1;
//	Node* Current = Head;
//	while (Current->NextNode != NULL) {
//		Current = Current->NextNode;
//		count++;
//	}
//	return count;
//}
//
//Node* SLL_SequentialSearch(Node* Head, int Target) {
//	Node* Current = Head; 
//	Node* Match = NULL;
//
//	while (Current != NULL) {
//		if (Current->Data == Target) {
//			Match = Current;
//			break;
//		}
//		else {
//			Current = Current->NextNode;
//		}
//	}
//
//	return Match;
//}
//
//Node* SLL_MoveToFront(Node** Head,int Target) {
//	Node* Current = *Head;
//	Node* Previous = NULL;
//	Node* Match = NULL;
//	
//	while (Current != NULL) {
//		if (Current->Data == Target) {
//			Match = Current;
//			Previous->NextNode = Match->NextNode;
//			Match->NextNode = (*Head);
//			(*Head) = Match;
//			break;
//		}
//		else {
//			Previous = Current;
//			Current = Current->NextNode;
//		}
//	}
//	return Match;
//}
//
//Node* SLL_Transpose(Node** Head, int Target) {
//	Node* Current = *Head;
//	Node* PPrevious = NULL;
//	Node* Previous = NULL;
//	Node* Match = NULL;
//
//	while (Current != NULL) {
//		if (Current->Data == Target) {
//			Match = Current;
//			if (Previous != NULL) {
//				if (PPrevious != NULL) {
//					PPrevious->NextNode = Current;
//				}
//				else {
//					(*Head) = Current;
//				}
//				Previous->NextNode = Current->NextNode;
//				Current->NextNode = Previous;
//			}
//			break;
//		}
//		else {
//			if (Previous != NULL) {
//				PPrevious = Previous;
//			}
//			Previous = Current;
//			Current = Current->NextNode;
//		}
//	}
//	return Match;
//}