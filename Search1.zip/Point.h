#ifndef POINT_H
#define POINT_H

#include <stdio.h>
#include <stdlib.h>



typedef struct tagPoint
{
    int    id;
    double point;
} Point;


Point* BinarySearch(Point pointset[], int Size, double Target);
int ComparePoint(const void* _elem1, const void* _elem2);


#endif // !POINT_H
