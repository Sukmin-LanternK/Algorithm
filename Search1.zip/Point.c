#include "Point.h"

Point* BinarySearch(Point pointset[], int Size, double Target){
	int Left = 0;
	int Right = Size - 1;
	int Mid; 

	while (Left <= Right) {
		Mid = (Left + Right) / 2;

		if (Target == pointset[Mid].point) {
			return &pointset[Mid];
		}
		else if (Target < pointset[Mid].point) {
			Right = Mid - 1;
		}
		else {
			Left = Mid + 1;
		}
	}
	return NULL;
}



int ComparePoint(const void* _elem1, const void* _elem2) {
	Point* elem1 = _elem1;
	Point* elem2 = _elem2;

	if (elem1->point > elem2->point) return 1;
	else if (elem1->point < elem2->point) return -1;
	else return 0;
}