#include "SBT.h"

void PrintSearchResult(int SearchTarget, SBTNode* Result) {
	if (Result != NULL) {
		printf("Found : %d \n", Result->Data);
	}
	else {
		printf("Not Found: %d\n", SearchTarget);
	}
}



int main() {
	// Create node
	SBTNode* Root = SBTNode_CreateNode(123);
	SBTNode* Node = NULL;

	// Create Tree 
	SBTNode_InsertNode(Root, SBTNode_CreateNode(22));
	SBTNode_InsertNode(Root, SBTNode_CreateNode(9918));
	SBTNode_InsertNode(Root, SBTNode_CreateNode(423));
	SBTNode_InsertNode(Root, SBTNode_CreateNode(17));
	SBTNode_InsertNode(Root, SBTNode_CreateNode(3));

	SBTNode_InsertNode(Root, SBTNode_CreateNode(98));
	SBTNode_InsertNode(Root, SBTNode_CreateNode(34));

	SBTNode_InsertNode(Root, SBTNode_CreateNode(760));
	SBTNode_InsertNode(Root, SBTNode_CreateNode(317));
	SBTNode_InsertNode(Root, SBTNode_CreateNode(1));

	SBTNode_InorderPrintTree(Root);
	printf("\n");

	printf("Removing 98");
	Node = SBTNode_RemoveNode(Root,NULL,98);
	SBTNode_DestroyNode(Node);
	SBTNode_InorderPrintTree(Root);
	printf("\n");


	printf("Inserting 111\n");
	SBTNode_InsertNode(Root, SBTNode_CreateNode(111));
	SBTNode_InorderPrintTree(Root);
	printf("\n");

	SBTNode_DestroyTree(Root);
	return 0;
}