#include "SBT.h"

SBTNode* SBTNode_CreateNode(ElementType Data) {
	SBTNode* NewNode = (SBTNode*)malloc(sizeof(SBTNode));
	NewNode->Left = NULL;
	NewNode->Right = NULL;
	NewNode->Data = Data;

	return NewNode;
}

void SBTNode_DestroyNode(SBTNode* Node) {
	free(Node);
}

void SBTNode_PreorderPrintTree(SBTNode* Node) {
	if (Node == NULL) return;
	printf("%c", Node->Data);

	SBTNode_PreorderPrintTree(Node->Left);
	SBTNode_PreorderPrintTree(Node->Right);
}

// %d�� ������ 
void SBTNode_InorderPrintTree(SBTNode* Node) {
	if (Node == NULL) return;
	SBTNode_InorderPrintTree(Node->Left);
	printf("%d ", Node->Data);
	SBTNode_InorderPrintTree(Node->Right);
}

void SBTNode_PostorderPrintTree(SBTNode* Node) {
	if (Node == NULL) return;
	SBTNode_PostorderPrintTree(Node->Left);
	SBTNode_PostorderPrintTree(Node->Right);
	printf("%c", Node->Data);
}

void SBTNode_DestroyTree(SBTNode* Node) {
	if (Node == NULL) return;
	SBTNode_PreorderPrintTree(Node->Left);
	SBTNode_PreorderPrintTree(Node->Right);
	SBTNode_DestroyNode(Node);
}
/********************************************************
����Ž�� Ʈ�� ���� �Լ�
*********************************************************/

SBTNode* SBTNode_SearchNode(SBTNode* Root, ElementType Target) {
	SBTNode* targetNode = Root;
	while (targetNode !=NULL && targetNode->Data == Target) {
		if (targetNode->Data > Target) {
			targetNode = targetNode->Left;
		}
		else {
			targetNode = targetNode->Right;
		}
	}
	return targetNode;
}

SBTNode* SBTNode_SearchMinNode(SBTNode* Root) {
	if (Root == NULL) return NULL;


	if (Root->Left == NULL) {
		return Root;
	}
	else {
		SBTNode_SearchMinNode(Root->Left);
	}
}

void SBTNode_InsertNode(SBTNode* Root, SBTNode* Child) {
	if (Root == NULL) {
		Root = Child;
		return 0;
	}
	
	SBTNode* Current = Root;
	SBTNode* Next = NULL;

	while (Current != NULL) {
		if (Current->Data > Child->Data) {
			Next = Current->Left;
			if (Next == NULL) {
				Current->Left = Child;
				return 0;
			}
			else {
				Current = Next;
			}
		}
		else if (Current->Data == Child->Data) {
			return -1;
		}
		else {
			Next = Current->Right;
			if (Next == NULL) {
				Current->Right = Child;
				return 0;
			}
			else {
				Current = Next;
			}
		}
	}
}

SBTNode* SBTNode_RemoveNode(SBTNode* Root, SBTNode* Parent, ElementType Target) {
	SBTNode* Removed = NULL;
	if (Root == NULL) {
		return NULL;
	}

	if (Root->Data > Target) {
		Removed = SBTNode_RemoveNode(Root->Left, Root, Target);
	}
	else if (Root->Data < Target) {
		Removed = SBTNode_RemoveNode(Root->Right, Root, Target);
	}
	else {
		Removed = Root;

		if (Removed->Left == NULL && Removed->Right == NULL) {
			if (Parent->Left == Root) {
				Parent->Left = NULL;
			}
			else if  (Parent->Right== Root) {
				Parent->Right = NULL;
			}
		}
		else if (Removed->Left != NULL && Removed->Right != NULL) {
			SBTNode* MInNode = SBTNode_SearchMinNode(Root->Right);
			MInNode = SBTNode_RemoveNode(Root, NULL, MInNode->Data);
			Root->Data = MInNode->Data;
		}
		else {
			// ����Ʈ ���ϵ� �̸�, ã�Ƽ� �з�Ʈ�� �¿� �������� �ٰ� 
			// ����Ʈ ���ϵ� �̸�, ã�Ƽ� �䷻Ʈ�� �¿� �������� �ٰ�
			SBTNode* Temp;
			if (Removed->Left != NULL) {
				Temp = Removed->Left;
			}
			else {
				Temp = Removed->Right;
			}
			
			if (Parent->Left == Root) {
				Parent->Left = Temp;
			}
			else if (Parent->Right == Root) {
				Parent->Right = Temp;
			}
		}

	}

	return Removed;
}