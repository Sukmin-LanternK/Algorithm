#pragma once
#include "SBT.h"


typedef struct tagBSTNODE {
	struct tagBSTNODE* Left;
	struct tagBSTNODE* Right;

	ElementType Data;
}BSTNode;