#pragma once
#include <stdio.h>
#include <stdlib.h>

typedef int ElementType;

typedef struct tagSBTNODE {
	struct tagSBTNODE* Left;
	struct tagSBTNODE* Right;

	ElementType Data;
}SBTNode;

SBTNode* SBTNode_CreateNode(ElementType Data);
void SBTNode_DestroyNode(SBTNode* Node);

void SBTNode_PreorderPrintTree(SBTNode* Node);
void SBTNode_InorderPrintTree(SBTNode* Node);
void SBTNode_PostorderPrintTree(SBTNode* Node);

void SBTNode_DestroyTree(SBTNode* Node);

/*******************************/

SBTNode* SBTNode_SearchNode(SBTNode* Root, ElementType Target);
SBTNode* SBTNode_SearchMinNode(SBTNode* Root);
void SBTNode_InsertNode(SBTNode* Root, SBTNode* Child);
SBTNode* SBTNode_RemoveNode(SBTNode* Root, SBTNode* Parent, ElementType Target);